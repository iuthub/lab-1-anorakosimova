<?php
    include("head.php");
?>
    <pre>
        <?php
            include("function.php");

            $name="Sarvar Abdullaev";
            $age=32;

            print_separate($name, "-");

            // print is_string($name) . "\n";
            // // print "Escape \"chars\" are the SAME as in Java!\n";
            // // print "You can have
            // // line breaks in a string.";
            // // print 'A string can use "single-quotes".\n It\'s cool!';

            // print is_string($name);
            // print gettype($name) . "\n";

            // print strcmp($name, "Sarvar");
            // print substr($name, 7, 90);
            // $names=explode(" ", $name);
            // print $names[1];

            // print "My last name is {$names[1]}!";
            // print "This is my {$age}th birthday";



        ?>
    </pre>

    <p>
        <?php
            $gender=0;
        ?>
        Here are my hobbies:

        <?php
            if($gender) {
            $hobbies=array_fill(0, 5, "football");
        ?>

        <h2><?= "I am male" ?></h2>

        <?php
            } else {
            $hobbies=array_fill(0, 5, "swimming");
        ?>

        <h2><?= "I am female" ?></h2>

        <?php } ?>

        <ul>
            <?php
            foreach($hobbies as $hobby){  ?>

            <li><?= $hobby ?></li>

            <?php } ?>
        </ul>
    </p>
<?php
    include("foot.php");
?>
















