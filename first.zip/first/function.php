<?php
    function print_separate($str, $separator=", ") {
        if(strlen($str)>0) {
            print $str[0];
            for($i=1;$i<strlen($str);$i++){
                if ($str[$i]==" " || $str[$i-1]==" ") {
                    print $str[$i];
                } else {
                    print $separator . $str[$i];
                }

            }
        }
    }
?>

