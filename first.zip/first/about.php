<?php
    include("head.php");
?>
    <h2>This is my About Page</h2>
    <p>
    <?php
        foreach(glob("*.txt") as $p){
            if($p!="\n") {
    ?>
        <a href="<?=$p?>"><?= $p ?></a><br>
    <?php
       }}

       file_put_contents("./access.log", "accessed!\n", FILE_APPEND);
    ?>
    </p>
<?php
    include("foot.php");
?>
