<?php include("head.php") ?>

<?php list($name, $phone, $email)=file("my_contacts.txt") ?>

<ul>
    <li><?= $name ?></li>
    <li><?= $phone ?></li>
    <li><?= $email ?></li>
</ul>

<?php include("foot.php") ?>
