<html>
<head>
    <meta charset="UTF-8">
    <title>My First PHP</title>
</head>
<body>
<h1>This is my PHP Page</h1>
